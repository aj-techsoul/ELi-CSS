function loadScript(url, callback)
{
    // Adding the script tag to the head as suggested before
    var head = document.head;
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;

    // Then bind the event to the callback function.
    // There are several events for cross browser compatibility.
    script.onreadystatechange = callback;
    script.onload = callback;

    // Fire the loading
    head.appendChild(script);
}

loadScript("jquery.min.js");
loadScript("swal/sweetalert2.all.min.js");
loadScript('eli-forms.js');
loadScript("eli-grid.js");
loadScript("eli-validation.js");
loadScript("eli_scripts.js");
